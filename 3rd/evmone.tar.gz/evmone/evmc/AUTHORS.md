# EVMC Authors

> The sorted list of EVMC authors for copyright purposes.

- Alex Beregszaszi
- Pawel Bylica [@chfast](https://github.com/chfast) <pawel@ethereum.org>
