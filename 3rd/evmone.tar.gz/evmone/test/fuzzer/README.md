# evmone-fuzzer

> [LibFuzzer] powered testing tool for [EVMC]-compatible EVM implementations.

## License

The evmone-fuzzer source code is licensed under the [Apache License, Version 2.0].


[Apache License, Version 2.0]: https://www.apache.org/licenses/LICENSE-2.0.txt
[EVMC]: https://github.com/ethereum/evmc
[LibFuzzer]: https://llvm.org/docs/LibFuzzer.html
