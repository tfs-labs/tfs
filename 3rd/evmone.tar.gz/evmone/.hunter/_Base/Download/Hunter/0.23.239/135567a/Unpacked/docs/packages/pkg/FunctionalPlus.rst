.. spelling::

    FunctionalPlus

.. index:: frameworks ; FunctionalPlus

.. _pkg.FunctionalPlus:

FunctionalPlus
==============

-  `Official <https://https://github.com/Dobiasd/FunctionalPlus/>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/FunctionalPlus/CMakeLists.txt>`__

.. literalinclude:: /../examples/FunctionalPlus/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
