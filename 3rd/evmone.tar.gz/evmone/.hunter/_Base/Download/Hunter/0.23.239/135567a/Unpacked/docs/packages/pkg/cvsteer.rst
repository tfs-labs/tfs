.. spelling::

    cvsteer

.. index:: computer-vision ; cvsteer

.. _pkg.cvsteer:

cvsteer
=======

-  `Official <http://github.com/headupinclouds/cvsteer>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/cvsteer/CMakeLists.txt>`__

.. literalinclude:: /../examples/cvsteer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
