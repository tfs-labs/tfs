OS
--

 * :ref:`pkg.Android-Apk`
 * :ref:`pkg.Android-Modules`
 * :ref:`pkg.Android-SDK`
 * :ref:`pkg.ios_sim`
 * :ref:`pkg.QtAndroidCMake`
 * :ref:`pkg.Washer` - Lightweight, header-only, C++ wrapper around the Windows API
 * :ref:`pkg.WTL` - Windows Template Library (WTL) is a C++ library for developing Windows applications and UI components.
