.. spelling::

    cppfs

.. index::
  single: unsorted ; cppfs

.. _pkg.cppfs:

cppfs
=====

-  `Official <https://github.com/cginternals/cppfs>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/cppfs/CMakeLists.txt>`__
-  Added by `Joerg-Christian Boehme <https://github.com/Bjoe>`__ (`pr-92 <https://github.com/cpp-pm/hunter/pull/92>`__)

.. literalinclude:: /../examples/cppfs/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
