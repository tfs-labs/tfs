.. spelling::

    CLI11

.. index::
  single: commandline tools ; CLI11

.. _pkg.CLI11:

CLI11
=====

-  `Official <https://github.com/CLIUtils/CLI11>`__
-  `Example <https://github.com/cpp-pm/hunter/blob/master/examples/CLI11/CMakeLists.txt>`__
-  Added by `Paweł Bylica <https://github.com/chfast>`__ (`pr-1446 <https://github.com/ruslo/hunter/pull/1446>`__)

.. literalinclude:: /../examples/CLI11/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
