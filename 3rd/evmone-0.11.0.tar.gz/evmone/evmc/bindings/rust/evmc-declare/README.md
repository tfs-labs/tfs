# evmc-declare

This is a Rust interface to [EVMC](https://github.com/ethereum/evmc).

This crate contains a declare macro for easily creating EVMC compatible VM implementations.
